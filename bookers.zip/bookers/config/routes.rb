Rails.application.routes.draw do
  root :to => 'homes#new'
  resources :books
end
