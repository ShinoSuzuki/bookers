class HomesController < ApplicationController
  def new
  end
end
